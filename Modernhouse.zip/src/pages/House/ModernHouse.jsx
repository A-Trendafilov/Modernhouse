import React from 'react';

const ModernHouse = () => {
    return (
        <div className="modern-house-page">
            <h1>Modern House</h1>
            <p>This is the Modern House section.</p>
        </div>
    );
};

export default ModernHouse;
