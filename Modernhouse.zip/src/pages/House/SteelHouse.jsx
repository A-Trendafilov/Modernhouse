import React from 'react';

const SteelHouse = () => {
    return (
        <div className="steel-house-page">
            <h1>Steel House</h1>
            <p>This is the Steel House section.</p>
        </div>
    );
};

export default SteelHouse;
