import React from "react";

const Container = () => {
  return (
    <div className="gallery-page">
      <h1>Container</h1>
      <p>This is the Container page.</p>
    </div>
  );
};

export default Container;
