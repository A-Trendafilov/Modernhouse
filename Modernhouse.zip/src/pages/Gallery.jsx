import React from 'react';

const Gallery = () => {
    return (
        <div className="gallery-page">
            <h1>Gallery</h1>
            <p>This is the Gallery page.</p>
        </div>
    );
};

export default Gallery;
